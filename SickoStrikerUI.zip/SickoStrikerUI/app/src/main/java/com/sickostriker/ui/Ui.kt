package com.sickostriker.ui

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

enum class Panel { NONE, NOTIFS, RECENTS, CONTROL }

data class Tile(
    val title: String, val sub: String, val icon: String, val c1: Color, val c2: Color,
    val pkgs: List<String> = emptyList(), val action: String? = null, val uri: String? = null
)

val TILES = listOf(
    Tile("Blood Strike", "Tactical Gaming Hub", "🎯", Color(0xFFFF2D55), Color(0xFF7C4DFF), listOf("com.netease.newspike"), uri = "https://play.google.com/store/apps/details?id=com.netease.newspike"),
    Tile("Media Center", "Stream & Watch", "🎬", Color(0xFF00E5FF), Color(0xFF2962FF), listOf("com.google.android.youtube.tv", "com.netflix.ninja"), uri = "https://www.youtube.com/tv"),
    Tile("Control Hub", "System Settings", "🎛️", Color(0xFF9C6BFF), Color(0xFF3D5AFE), action = Settings.ACTION_SETTINGS),
    Tile("Browser OS", "Web Everywhere", "🌐", Color(0xFF00E676), Color(0xFF00B8D4), uri = "https://www.google.com"),
    Tile("Play Store", "Apps & Games", "🛍️", Color(0xFF69F0AE), Color(0xFF1DE9B6), listOf("com.android.vending")),
    Tile("YouTube", "Videos", "▶️", Color(0xFFFF5252), Color(0xFFD50000), listOf("com.google.android.youtube.tv", "com.google.android.youtube")),
    Tile("Netflix", "Series & Films", "🍿", Color(0xFFFF1744), Color(0xFF880E4F), listOf("com.netflix.ninja")),
    Tile("Wi-Fi", "Network", "📶", Color(0xFF40C4FF), Color(0xFF0091EA), action = Settings.ACTION_WIFI_SETTINGS)
)

fun launch(c: Context, t: Tile): Boolean {
    val pm = c.packageManager
    for (p in t.pkgs) {
        val i = pm.getLeanbackLaunchIntentForPackage(p) ?: pm.getLaunchIntentForPackage(p)
        if (i != null && runCatching { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess) return true
    }
    val i = when {
        t.action != null -> Intent(t.action)
        t.uri != null -> Intent(Intent.ACTION_VIEW, Uri.parse(t.uri))
        else -> return false
    }
    return runCatching { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess
}

fun Modifier.glass(shape: Shape, focused: Boolean = false): Modifier = this
    .clip(shape)
    .background(Brush.verticalGradient(listOf(Color.White.copy(.16f), Color.White.copy(.05f))))
    .border(
        if (focused) 3.dp else 1.dp,
        if (focused) Brush.linearGradient(listOf(Color(0xFF00E5FF), Color(0xFFFF2D95)))
        else SolidColor(Color.White.copy(.18f)), shape
    )

@Composable
fun Modifier.autoFocus(): Modifier {
    val r = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { r.requestFocus() } }
    return this.focusRequester(r)
}

@Composable
fun SickoApp(aod: Boolean, panel: Panel, setPanel: (Panel) -> Unit, sleep: () -> Unit) {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(1000) } }
    val recents = remember { mutableStateListOf<Tile>() }
    var launching by remember { mutableStateOf<Tile?>(null) }
    var toast by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(toast) { if (toast != null) { delay(2500); toast = null } }
    LaunchedEffect(launching) {
        val t = launching ?: return@LaunchedEffect
        delay(900)
        recents.remove(t); recents.add(0, t)
        if (!launch(ctx, t)) toast = "${t.title} couldn't be opened on this device"
        launching = null
    }
    BackHandler { if (launching != null) launching = null else setPanel(Panel.NONE) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (aod) { AodScreen(now); return@Box }
        LiquidBackground()
        Column(Modifier.fillMaxSize().padding(horizontal = 64.dp, vertical = 36.dp), verticalArrangement = Arrangement.spacedBy(24.dp)) {
            Header(now)
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (panel) {
                    Panel.NONE -> Home { launching = it }
                    Panel.NOTIFS -> NotifPanel()
                    Panel.RECENTS -> RecentsPanel(recents) { launching = it }
                    Panel.CONTROL -> ControlPanel(ctx, sleep)
                }
            }
            Dock(panel, setPanel)
        }
        launching?.let { LaunchOverlay(it) }
        toast?.let {
            Text(it, color = Color.White, fontSize = 18.sp,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 28.dp)
                    .glass(RoundedCornerShape(50)).padding(horizontal = 28.dp, vertical = 12.dp))
        }
    }
}

@Composable
fun LiquidBackground() {
    val t = rememberInfiniteTransition(label = "bg")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(18000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF05010F), Color(0xFF0B1030), Color(0xFF14061F))))) {
        Canvas(Modifier.fillMaxSize().blur(70.dp)) {
            val w = size.width; val h = size.height
            drawCircle(Color(0xFF00E5FF).copy(.35f), h * .45f, Offset(w * (.2f + .3f * a), h * (.3f + .2f * a)))
            drawCircle(Color(0xFFFF2D95).copy(.30f), h * .5f, Offset(w * (.8f - .3f * a), h * (.7f - .2f * a)))
            drawCircle(Color(0xFF7C4DFF).copy(.35f), h * .4f, Offset(w * .5f, h * (.2f + .5f * (1 - a))))
        }
    }
}

@Composable
fun Header(now: LocalDateTime) {
    val (icon, temp) = if (now.hour in 6..18) "☀️" to "28° Sunny" else "🌙" to "24° Clear" // swap for a real weather API
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(now.format(DateTimeFormatter.ofPattern("HH:mm")), color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Light)
            Text(now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")), color = Color.White.copy(.7f), fontSize = 20.sp)
        }
        Text("SICKO STRIKER UI", color = Color(0xFF00E5FF), fontSize = 16.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
        Spacer(Modifier.width(32.dp))
        Text("$icon  $temp", color = Color.White, fontSize = 22.sp,
            modifier = Modifier.glass(RoundedCornerShape(50)).padding(horizontal = 24.dp, vertical = 12.dp))
    }
}

@Composable
fun Home(onOpen: (Tile) -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(24.dp)) {
        TILES.chunked(4).forEachIndexed { r, row ->
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                row.forEachIndexed { c, t ->
                    val m = Modifier.weight(1f).fillMaxHeight()
                    TileCard(t, if (r == 0 && c == 0) m.autoFocus() else m) { onOpen(t) }
                }
            }
        }
    }
}

@Composable
fun TileCard(t: Tile, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var f by remember { mutableStateOf(false) }
    val s by animateFloatAsState(if (f) 1.07f else 1f, spring(dampingRatio = .6f), label = "s")
    val shape = RoundedCornerShape(28.dp)
    Box(
        modifier.graphicsLayer { scaleX = s; scaleY = s }
            .shadow(if (f) 28.dp else 0.dp, shape, ambientColor = t.c1, spotColor = t.c1)
            .onFocusChanged { f = it.isFocused }
            .glass(shape, f)
            .background(Brush.linearGradient(listOf(t.c1.copy(.4f), t.c2.copy(.12f))))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(t.icon, fontSize = 52.sp)
            Spacer(Modifier.height(8.dp))
            Text(t.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(t.sub, color = Color.White.copy(.7f), fontSize = 14.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun GlassButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var f by remember { mutableStateOf(false) }
    val s by animateFloatAsState(if (f) 1.06f else 1f, label = "s")
    Box(
        modifier.graphicsLayer { scaleX = s; scaleY = s }
            .onFocusChanged { f = it.isFocused }
            .glass(RoundedCornerShape(20.dp), f)
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 16.dp)
    ) { Text(label, color = Color.White, fontSize = 18.sp) }
}

@Composable
fun Sheet(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().glass(RoundedCornerShape(32.dp)).padding(32.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        content()
    }
}

@Composable
fun NotifPanel() {
    val items = remember { mutableStateListOf("🎯|Blood Strike|New season starts tonight", "🎬|Media Center|3 new episodes ready", "⬇️|System|Update available", "📶|Control Hub|Connected to Wi-Fi") }
    Sheet("Notifications") {
        GlassButton("🧹  Clear all", Modifier.autoFocus()) { items.clear() }
        if (items.isEmpty()) Text("You're all caught up", color = Color.White.copy(.7f), fontSize = 18.sp)
        items.toList().forEach { s ->
            val p = s.split("|")
            key(s) { GlassButton("${p[0]}  ${p[1]} — ${p[2]}  (OK to dismiss)") { items.remove(s) } }
        }
    }
}

@Composable
fun RecentsPanel(recents: SnapshotStateList<Tile>, onOpen: (Tile) -> Unit) {
    Sheet("Recent Apps") {
        if (recents.isEmpty()) Text("Nothing here yet. Launch a tile from Home.", color = Color.White.copy(.7f), fontSize = 18.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            recents.toList().forEachIndexed { i, t ->
                val m = Modifier.width(220.dp).height(150.dp)
                TileCard(t, if (i == 0) m.autoFocus() else m) { onOpen(t) }
            }
        }
        if (recents.isNotEmpty()) GlassButton("🗑  Clear recents") { recents.clear() }
    }
}

@Composable
fun ControlPanel(ctx: Context, sleep: () -> Unit) {
    val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    var vol by remember { mutableIntStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC)) }
    fun adj(d: Int) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, d, 0); vol = am.getStreamVolume(AudioManager.STREAM_MUSIC) }
    fun open(a: String) { runCatching { ctx.startActivity(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
    val acts = listOf<Pair<String, () -> Unit>>(
        "🔉  Volume −" to { adj(AudioManager.ADJUST_LOWER) },
        "🔊  Volume +" to { adj(AudioManager.ADJUST_RAISE) },
        "🔇  Mute" to { adj(AudioManager.ADJUST_TOGGLE_MUTE) },
        "🌙  Always-On Display" to sleep,
        "📶  Wi-Fi" to { open(Settings.ACTION_WIFI_SETTINGS) },
        "🔵  Bluetooth" to { open(Settings.ACTION_BLUETOOTH_SETTINGS) },
        "🖥️  Display" to { open(Settings.ACTION_DISPLAY_SETTINGS) },
        "⚙️  All Settings" to { open(Settings.ACTION_SETTINGS) }
    )
    Sheet("Control Panel   •   Volume $vol / $max") {
        acts.chunked(4).forEachIndexed { r, row ->
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                row.forEachIndexed { c, (l, a) -> GlassButton(l, if (r == 0 && c == 0) Modifier.autoFocus() else Modifier, a) }
            }
        }
    }
}

@Composable
fun Dock(panel: Panel, setPanel: (Panel) -> Unit) {
    val items = listOf(Triple(Panel.NONE, "🏠", "Home"), Triple(Panel.RECENTS, "🗂️", "Recents"), Triple(Panel.NOTIFS, "🔔", "Alerts"), Triple(Panel.CONTROL, "🎚️", "Control"))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
        Row(Modifier.glass(RoundedCornerShape(40.dp)).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            items.forEach { (p, icon, label) ->
                var f by remember { mutableStateOf(false) }
                val s by animateFloatAsState(if (f) 1.18f else 1f, spring(dampingRatio = .55f), label = "d")
                Column(
                    Modifier.graphicsLayer { scaleX = s; scaleY = s }
                        .onFocusChanged { f = it.isFocused }
                        .glass(RoundedCornerShape(28.dp), f)
                        .background(if (panel == p) Color.White.copy(.18f) else Color.Transparent)
                        .clickable { setPanel(p) }
                        .padding(horizontal = 28.dp, vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(icon, fontSize = 30.sp)
                    Text(label, color = Color.White, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun LaunchOverlay(t: Tile) {
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(t.c1.copy(.92f), t.c2.copy(.95f)))), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(t.icon, fontSize = 96.sp)
            Text("Launching ${t.title}…", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text(t.sub, color = Color.White.copy(.8f), fontSize = 18.sp)
        }
    }
}

@Composable
fun AodScreen(now: LocalDateTime) {
    val shift = (now.minute % 6 - 3) * 20 // drifts each minute to avoid burn-in
    Column(Modifier.fillMaxSize().offset(shift.dp, (-shift).dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text(now.format(DateTimeFormatter.ofPattern("HH:mm")), color = Color.White.copy(.55f), fontSize = 120.sp, fontWeight = FontWeight.Thin)
        Text(now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")), color = Color.White.copy(.35f), fontSize = 24.sp)
    }
}
