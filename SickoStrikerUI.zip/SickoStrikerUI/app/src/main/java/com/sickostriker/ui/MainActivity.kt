package com.sickostriker.ui

import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private var lastInput = System.currentTimeMillis()
    private var aod by mutableStateOf(false)
    private var panel by mutableStateOf(Panel.NONE)

    /** Remote engine: any key wakes AOD; MENU/SETTINGS, INFO, APP_SWITCH open panels. */
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        lastInput = System.currentTimeMillis()
        if (aod) { if (e.action == KeyEvent.ACTION_DOWN) aod = false; return true }
        if (e.action == KeyEvent.ACTION_DOWN) {
            val target = when (e.keyCode) {
                KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_SETTINGS -> Panel.CONTROL
                KeyEvent.KEYCODE_INFO -> Panel.NOTIFS
                KeyEvent.KEYCODE_APP_SWITCH -> Panel.RECENTS
                else -> null
            }
            if (target != null) { panel = if (panel == target) Panel.NONE else target; return true }
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LaunchedEffect(Unit) {
                while (true) {
                    delay(1000)
                    if (!aod && System.currentTimeMillis() - lastInput > 60_000) aod = true
                }
            }
            SickoApp(aod, panel, { panel = it }, { aod = true })
        }
    }
}
